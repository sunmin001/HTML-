//
//  AppDelegate.h
//  Cesh
//
//  Created by kgc－mac on 2019/4/11.
//  Copyright © 2019 kgc－mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

